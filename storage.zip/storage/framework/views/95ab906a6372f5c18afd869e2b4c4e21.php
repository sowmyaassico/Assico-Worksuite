<div class="align-items-center d-flex flex-column text-lightest p-20 w-100">
    <i class="fa fa-<?php echo e($icon); ?> f-21 w-100"></i>

    <div class="f-15 mt-4">
        - <?php echo e($message); ?> -
    </div>
</div>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/cards/no-record.blade.php ENDPATH**/ ?>