<!-- Datatables -->
<?php echo $__env->make('sections.daterange_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" defer="defer">

<link rel="stylesheet" href="<?php echo e(asset('vendor/datatables/buttons.dataTables.min.css')); ?>" defer="defer">
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatables/buttons.bootstrap4.min.css')); ?>" defer="defer">
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/sections/datatable_css.blade.php ENDPATH**/ ?>