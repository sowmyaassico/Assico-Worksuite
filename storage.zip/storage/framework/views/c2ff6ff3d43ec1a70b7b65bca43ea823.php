<?php $__env->startSection('content'); ?>
    
<div class="content-wrapper">
    <?php echo $__env->make($view, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/projects/create.blade.php ENDPATH**/ ?>