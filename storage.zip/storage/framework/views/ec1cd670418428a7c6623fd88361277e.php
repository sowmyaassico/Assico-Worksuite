<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
            <?php echo e($slot); ?>

        </a>
    </td>
</tr>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>