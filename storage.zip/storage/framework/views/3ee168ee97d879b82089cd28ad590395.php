<i class='fa fa-circle mr-2 text-<?php echo e($color); ?>' <?php if(isset($style) && $style != ''): ?> style="<?php echo e($style); ?>" <?php endif; ?>></i><?php echo e($value); ?>


<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/status.blade.php ENDPATH**/ ?>