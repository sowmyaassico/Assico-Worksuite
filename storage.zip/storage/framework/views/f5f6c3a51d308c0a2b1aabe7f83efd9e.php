<div <?php echo e($attributes->merge(['class' => 'settings-btns py-3 d-flex justify-content-start px-4'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/setting-form-actions.blade.php ENDPATH**/ ?>