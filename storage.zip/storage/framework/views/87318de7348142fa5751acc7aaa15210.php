<div class="filter-box">
    <!-- FILTER START -->
    <form action="" id="filter-form">
        <div
            <?php echo e($attributes->merge(['class' => 'd-lg-flex d-md-flex d-block flex-wrap filter-box bg-white client-list-filter'])); ?>>
            <?php echo e($slot); ?>

        </div>
    </form>

</div>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/filters/filter-box.blade.php ENDPATH**/ ?>