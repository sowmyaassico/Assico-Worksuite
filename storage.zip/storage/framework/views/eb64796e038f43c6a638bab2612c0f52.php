<div class="card-header bg-white border-0 text-capitalize d-flex justify-content-between pt-4">
    <h4 class="f-18 f-w-500 mb-0"><?php echo e($slot); ?></h4>

    <?php if($action): ?>
        <?php echo $action; ?>

    <?php endif; ?>

</div>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/cards/card-header.blade.php ENDPATH**/ ?>