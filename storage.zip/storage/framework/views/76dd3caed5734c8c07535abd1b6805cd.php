<li <?php echo e($isActive($menu) ? 'class=active' : ''); ?> <?php echo e($attributes); ?> >
    <a class="d-block f-15 text-dark-grey text-capitalize border-bottom-grey" href="<?php echo e($href); ?>"><?php echo e($text); ?></a>
</li>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/setting-menu-item.blade.php ENDPATH**/ ?>