<div class="row">
    <div class="col-sm-6">
            <div class="bg-white rounded add-client">
        <form id="resource-form" method="post" autocomplete="off" novalidate="novalidate" enctype="multipart/form-data">
            <input type="hidden" name="id" id="id" value="<?php echo e(empty($obj->id) ? 0 : $obj->id); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                    <input type="hidden" name="type" id="type" value="<?php echo e($type); ?>">
                    <input type="hidden" name="parent_id" id="parent_id" value="0">
                    <input type="hidden" name="document_name" id="document_name" value="">
                <?php if($type == 2): ?>
                <?php if(empty($obj->id)): ?>
                <div class="mb-3">
                    <label class="form-label" for="name">Document</label>
                   
                    <input type="file" id="document" name="document" onchange="fileSelect(event)" class="form-control height-35 f-14" required>
                </div>
                <?php endif; ?>
                <div class="mb-3">
                    <label class="form-label" for="name">File name</label>
                    <input type="input" id="version" name="version" value="<?php echo e(old('version', $obj->version)); ?>" class="form-control height-35 f-14" required>
                </div>
                <?php else: ?>
                <div class="mb-3">
                    <label class="form-label" for="name">Folder Name</label>
                    <input type="text" id="document" name="document" value="<?php echo e(old('version', $obj->version)); ?>" class="form-control height-35 f-14" required>
                </div>
                
                <?php endif; ?> 
              </div>
            <button type="button" class="btn btn-light">Cancel</button>&nbsp;&nbsp;
            <button type="submit" class="btn btn-primary">Save</button>
            
    </form>
</div>
    </div>
</div>

<script>
$(document).ready(function() {
    $("#resource-form").submit(function(event) { 
        event.preventDefault();
            var me = $(this);
            if ( me.data('requestRunning') ) {
                return;
            }
            me.data('requestRunning', true);
            var form = $('#resource-form')[0];
            var formData = new FormData(form);
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('filemanager.create.update.post')); ?>",
                processData: false,
                contentType: false,
                data: formData,
                success: function(data) {
                    $("#datatable_resource").DataTable().draw(false);
                    //data = JSON.parse(data);
                    closeTaskDetail();
                },
                error: function(error) {
                    me.data('requestRunning', false);
                },
                complete: function() {
                    me.data('requestRunning', false);
                }
            });
    });
});
    function fileSelect(e){
        $("#version").val(e.target.files[0].name);
        $("#document_name").val(e.target.files[0].name);
    }

</script>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/filemanager/ajax/create.blade.php ENDPATH**/ ?>