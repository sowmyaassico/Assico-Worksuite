<div <?php echo e($attributes->merge(['class' => 'w-100 border-top-grey d-block d-lg-flex d-md-flex justify-content-start px-4 py-3'])); ?>>
    <?php echo e($slot); ?>

</div>

<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/form-actions.blade.php ENDPATH**/ ?>