<a href="<?php echo e($link); ?>" <?php echo e($attributes->merge(['class' => 'btn-cancel rounded f-14 p-2'])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/forms/button-cancel.blade.php ENDPATH**/ ?>