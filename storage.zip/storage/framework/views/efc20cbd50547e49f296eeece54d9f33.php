<span class="f-12 p-1 "><?php echo e($month); ?></span>
<span class="f-13 f-w-500 rounded-bottom"><?php echo e($date); ?></span>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/date-badge.blade.php ENDPATH**/ ?>