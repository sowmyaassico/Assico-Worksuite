<div <?php echo e($attributes->merge(['class' => 's-b-n-header'])); ?> id="tabs">
    <nav class="tabs px-4 border-bottom-grey">
        <div class="nav" id="nav-tab" role="tablist">

            <?php echo e($slot); ?>


        </div>
    </nav>
</div>
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/tab-section.blade.php ENDPATH**/ ?>