<!-- Task Detail Start -->
<div class="task-overlay w-100 h-100" id="close-task-detail-overlay"></div>
<div class="task-detail-panel bg-additional-grey" id="task-detail-1">
    <a class="close-task-detail" id="close-task-detail" style="display: none;">
        <span><i class="fa fa-times"></i></span>
    </a>
    <div class="p-4 t-d-inner-panel">
        <h3 class="heading-h1 mb-0" id="right-modal-title"></h3>

        <div id="right-modal-content" class="mt-4 mb-5">

        </div>
    </div>
</div>
<!-- Task Detail End -->
<?php /**PATH /home/u546901281/domains/abms.assicolabs.com/public_html/resources/views/components/right-modal.blade.php ENDPATH**/ ?>